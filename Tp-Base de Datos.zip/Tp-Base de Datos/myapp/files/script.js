
const botones = document.getElementsByClassName("btn");
const audio = new Audio();
const nombre = document.getElementsByClassName("nombre");
const duracion = document.getElementsByClassName("duracion");
const tipo = document.getElementsByClassName("tipo");
const autor = document.getElementsByClassName("autor");
const reproducciones = document.getElementsByClassName("reproducciones")
for(let boton of botones){
    let datos = {id: boton.getAttribute("sql")};
    $.ajax({
        url: "http://localhost:3000/datos",
        type: 'POST',
        contentType: "application/json",
        data: JSON.stringify(datos)
    })
    .done(function (data) {
        console.log
        boton.innerHTML = data[0].nombre;
        boton.setAttribute("src", data[0].src);
    })
    .fail(function (jqXHR, textStatus, errorThrown) {
    console.log("error, no se pudo ingresar los nuevos datos");
    console.log(jqXHR);
    console.log(textStatus);
    console.log(errorThrown);
});
    }

function reproducirAudio(boton){
    audio.pause();
    let id = boton.getAttribute("sql");
    let datos = {
        id: id,
    };
    $.ajax({
        url: "http://localhost:3000/subir",
        type: 'POST',
        contentType: "application/json",
        data: JSON.stringify(datos)
    }).done(function (data) {})
      .fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo ingresar los nuevos datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
    datos = {id: boton.getAttribute("sql")};
    $.ajax({
        url: "http://localhost:3000/datos",
        type: 'POST',
        contentType: "application/json",
        data: JSON.stringify(datos)
    }).done(function (data) {
        nombre.innerHTML = data[0].nombre;
        duracion.innerHTML = data[0].duracion;
        tipo.innerHTML = data[0].tipo;
        autor.innerHTML = data[0]
    }).fail(function (jqXHR, textStatus, errorThrown) {
        console.log("error, no se pudo ingresar los nuevos datos");
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    });
    audio.src = boton.getAttribute("src");
    audio.play();
}

